This is my java project for CSC 122

HOW TO PLAY
-Your goal is to keep the duckling alive aslong as possible-

CONTROLS
left click to interact with buttons and duck
right click to move the duck

You must put it to sleep, clean it, feed it, play with it, and let it potty

if it does not sleep it will die
if it does not eat it will die
if it is not clean it will die
if it is bored it will die

The duck will indicate what it needs whether that be its tummy growling or it getting dirty

expect to kill atleast one duck
